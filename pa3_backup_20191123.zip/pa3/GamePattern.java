
public class GamePattern {
	private int m_int;

	GamePattern(int i) {
		m_int = i;
	}

	public int getValue() {
		return m_int;
	}

	public void setValue(int i) {
		m_int = i;
	}
}