import java.util.*;

public class QTable {
	ArrayList<ArrayList<Double>> m_table;

	QTable() {
		m_table = new ArrayList<ArrayList<Double>>();
	}
}