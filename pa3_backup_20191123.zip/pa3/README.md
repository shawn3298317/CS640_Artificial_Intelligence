# 4x4x4 Tic-Tac-Toe AI

## TODO:
1. multi-thread min-max agent
2. RLAgent (DeepQ)

## Agents to Implement
- Random Agents (baseline)
- Alpha-Beta Min-max Agent (Value functions??)
- (can skip) Monte-Carlo Agent (Value functions??)
- RL Agent?
- // DQN Agent?
