javac *.java
java runTicTacToe
